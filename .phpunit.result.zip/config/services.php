<?php

return array (
  'postmark' => 
  array (
    'token' => NULL,
  ),
  'ses' => 
  array (
    'key' => '',
    'secret' => '',
    'region' => 'us-east-1',
  ),
  'resend' => 
  array (
    'key' => NULL,
  ),
  'slack' => 
  array (
    'notifications' => 
    array (
      'bot_user_oauth_token' => NULL,
      'channel' => NULL,
    ),
  ),
  'webmoney' => 
  array (
    'merchant_purse' => 'Z661920790299',
    'secret_key' => 'rwr4w54$#$552',
    'sim_mode' => '1',
  ),
);
