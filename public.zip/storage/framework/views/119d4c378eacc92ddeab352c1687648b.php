<?php echo e($slot); ?>

<?php /**PATH C:\Users\akess\OneDrive\Documents\jobs\renting\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>