

<?php $__env->startSection('hero_text'); ?>
    <?php echo e($title ?? 'Уведомление'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h2><?php echo e($greeting ?? 'Здравствуйте!'); ?></h2>
    
    <div style="margin-top: 20px;">
        <?php $__currentLoopData = $introLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($line); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php if(isset($actionText)): ?>
        <div style="text-align: center; margin: 30px 0;">
            <a href="<?php echo e($actionUrl); ?>" class="btn" target="_blank"><?php echo e($actionText); ?></a>
        </div>
    <?php endif; ?>

    <div>
        <?php $__currentLoopData = $outroLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($line); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div style="margin-top: 25px;">
        <p>С уважением,<br><?php echo e(config('app.name')); ?></p>
    </div>

    <?php if(isset($actionText)): ?>
        <div class="divider"></div>
        <div style="color: #8B8B8B; font-size: 13px; margin-top: 15px;">
            Если у вас возникли проблемы с нажатием кнопки "<?php echo e($actionText); ?>", скопируйте и вставьте URL-адрес ниже в ваш веб-браузер:
            <br>
            <a href="<?php echo e($actionUrl); ?>" style="word-break: break-all;"><?php echo e($actionUrl); ?></a>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('emails.custom-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\akess\OneDrive\Documents\jobs\renting\resources\views/emails/custom-notification.blade.php ENDPATH**/ ?>