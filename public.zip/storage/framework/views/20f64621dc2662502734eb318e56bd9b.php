<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="mb-6">
        <h1 class="text-2xl font-bold">Транзакции</h1>
    </div>

    <div class="hidden md:block overflow-x-auto">
        <table class="w-full border-collapse">
            <thead class="bg-[#191919] text-left">
                <tr>
                    <th class="px-4 py-3 text-sm font-medium">№</th>
                    <th class="px-4 py-3 text-sm font-medium">Дата</th>
                    <th class="px-4 py-3 text-sm font-medium">Услуга</th>
                    <th class="px-4 py-3 text-sm font-medium">Статус</th>
                    <th class="px-4 py-3 text-sm font-medium">Стоимость</th>
                    <th class="px-4 py-3 text-sm font-medium">Чек</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-b border-gray-800 text-[#C2C2C2]">
                    <td class="px-4 py-3 text-sm">№<?php echo e($transaction->id); ?></td>
                    <td class="px-4 py-3 text-sm"><?php echo e($transaction->created_at->format('d.m.Y')); ?></td>
                    <td class="px-4 py-3 text-sm"><?php echo e($transaction->type == 'purchase' ? 'Оплата рекламы' : 'Пополнение'); ?></td>
                    <td class="px-4 py-3 text-sm">
                        <?php if($transaction->status == 'completed'): ?>
                        <span class="inline-flex px-4 py-2 text-xs rounded-lg bg-[#A6FF6A99] text-black">
                            Выполнено
                        </span>
                        <?php elseif($transaction->status == 'pending'): ?>
                        <span class="inline-flex px-5 py-2 text-xs rounded-lg bg-[#FFE66699] text-black">
                            Ожидаем
                        </span>
                        <?php else: ?>
                        <span class="inline-flex px-4 py-2 text-xs rounded-lg bg-[#FF6C6C99] text-black">
                            Отклонено
                        </span>
                        <?php endif; ?>
                    </td>
                    <td class="px-4 py-3 text-sm"><?php echo e(number_format($transaction->amount, 0, '.', ' ')); ?> р.</td>
                    <td class="px-4 py-3 text-sm">
                        <?php if($transaction->status == 'completed'): ?>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 inline-block" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V7a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                            </svg>
                        </a>
                        <?php else: ?>
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 inline-block text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V7a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr class="border-b border-gray-800">
                    <td colspan="6" class="px-4 py-6 text-center text-gray-400">У вас пока нет транзакций</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Cards for small screens -->
    <div class="md:hidden space-y-4">
        <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="bg-[#1C1C1C] rounded-xl p-4 mb-4 text-white relative">
            <div class="text-xl font-semibold mb-4"><?php echo e(number_format($transaction->amount, 0, '.', ' ')); ?> р.</div>
            <?php if($transaction->status == 'completed'): ?>
            <span class="absolute top-4 right-4 bg-[#A6FF6A99] text-black text-sm px-3 py-2 rounded-lg">Выполнено</span>
            <?php elseif($transaction->status == 'pending'): ?>
            <span class="absolute top-4 right-4 bg-[#FFE66699] text-black text-sm px-3 py-2 rounded-lg">Ожидаем</span>
            <?php else: ?>
            <span class="absolute top-4 right-4 bg-[#FF6C6C99] text-black text-sm px-3 py-2 rounded-lg">Отклонено</span>
            <?php endif; ?>
            <hr class="border-gray-700 my-4">
            <div class="text-sm text-[#C2C2C2]">№<?php echo e($transaction->id); ?></div>
            <div class="text-sm text-[#C2C2C2]"><?php echo e($transaction->created_at->format('d.m.Y')); ?></div>
            <div class="text-sm text-[#C2C2C2] mb-4"><?php echo e($transaction->type == 'purchase' ? 'Оплата рекламы' : 'Пополнение'); ?></div>
            <?php if($transaction->status == 'completed'): ?>
            <a href="#" class="block w-full bg-[#7A5FFF] hover:bg-[#6a52e6] text-white py-2 rounded-xl text-sm font-medium text-center">Получить чек</a>
            <?php else: ?>
            <button disabled class="w-full bg-gray-700 text-gray-400 py-2 rounded-xl text-sm font-medium cursor-not-allowed">Получить чек</button>
            <?php endif; ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="bg-[#1C1C1C] rounded-xl p-6 text-center text-gray-400">
            У вас пока нет транзакций
        </div>
        <?php endif; ?>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\akess\OneDrive\Documents\jobs\renting\resources\views/transactions/index.blade.php ENDPATH**/ ?>