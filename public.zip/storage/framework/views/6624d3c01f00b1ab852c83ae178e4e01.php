<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  <div class="flex pr-3 pl-3 items-center justify-between mb-4">
    <h1 class="text-2xl font-bold">Анкеты</h1>
    <a href="<?php echo e(route('user.form.index')); ?>"
      class="px-6 py-2 border border-white-700 rounded-md text-white text-sm transition">
      Добавить анкету
    </a>
  </div>

  <?php if(count($profiles) == 0): ?>
    <!-- Empty state message -->
    <div class="bg-[#191919] rounded-2xl p-8 text-center">
    <svg xmlns="http://www.w3.org/2000/svg" class="h-16 w-16 mx-auto mb-4 text-gray-400" fill="none" viewBox="0 0 24 24"
      stroke="currentColor">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
      d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
    </svg>
    <h2 class="text-xl font-semibold mb-2">У вас пока нет анкет</h2>
    <p class="text-gray-400 mb-6">Создайте свою первую анкету, чтобы начать получать заказы</p>
    <a href="<?php echo e(route('user.form.index')); ?>"
      class="px-6 py-3 bg-[#6340FF] hover:bg-[#5737e7] text-white rounded-xl text-sm transition inline-block">
      Создать анкету
    </a>
    </div>
  <?php else: ?>

    <!-- Tabs for desktop - now with pill-like edges -->
    


    <!-- Profiles list - Desktop -->
    <div class="p-3 hidden lg:block">

    <div class=" w-full">
      <table class="min-w-full table-auto">
      <thead>
        <tr class="bg-[#191919]">
        <th class="w-1/3 p-4 text-sm text-white text-left">Основные данные</th>
        <th class="w-1/3 p-4 text-sm text-white text-left">Локация</th>
        <th class="w-1/6 p-4 text-sm text-white text-center">Просмотры</th>
        <th class="w-1/6 p-4 text-sm text-white text-center">Клики</th>
        <th class="w-1/6 p-4 text-sm text-white text-left">Реклама</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <tr class="border-b border-gray-800">
      <!-- Profile cell -->
      <td class="p-4 align-top">
        <div class="flex items-center">
        <div class="w-12 h-12 rounded-full overflow-hidden mr-3 bg-gray-800">
        <img src="<?php echo e(asset('storage/' . $profile->primaryImage->path)); ?>" alt="Profile"
        class="w-full h-full object-cover">
        </div>
        <div>
        <div class="flex items-center gap-2">
        <span class="font-medium text-white"><?php echo e($profile->name); ?>, <?php echo e($profile->age); ?></span>
        <?php if($profile->is_active): ?>
      <span class="text-xs bg-[#5FD013] text-black px-2 py-0.5 rounded-md">Активна</span>
    <?php else: ?>
    <span class="text-xs bg-[#49494999] text-white px-2 py-0.5 rounded-md">Неактивна</span>
  <?php endif; ?>
        </div>
        <div class="text-xs text-gray-400">Анкета добавлена <?php echo e($profile->created_at->format('d.m.Y')); ?></div>
        </div>
        </div>
      </td>

      <!-- Location cell -->
      <td class="p-4 text-sm text-[#C2C2C2] align-top">
        <div class="flex items-center mb-1">
        <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 mr-1 flex-shrink-0" viewBox="0 0 24 24">
        <circle cx="12" cy="12" r="10" fill="none" stroke="#FF000099" stroke-width="2" />
        <text x="12" y="16" text-anchor="middle" font-size="12" font-weight="bold" fill="#FF000099"
        font-family="Arial, sans-serif">M</text>
        </svg>
        <?php $__currentLoopData = $profile->neighborhoods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $neighborhood): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php echo e($neighborhood->name); ?>

      <?php if($key < count($profile->neighborhoods) - 1): ?>
      ,
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="flex items-center">
        <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 mr-1 flex-shrink-0" viewBox="0 0 24 24">
        <circle cx="12" cy="12" r="10" fill="none" stroke="#FF000099" stroke-width="2" />
        <text x="12" y="16" text-anchor="middle" font-size="12" font-weight="bold" fill="#FF000099"
        font-family="Arial, sans-serif">M</text>
        </svg>
        <?php $__currentLoopData = $profile->metroStations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $metroStation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      м. <?php echo e($metroStation->name); ?>

      <?php if($key < count($profile->metroStations) - 1): ?>
      ,
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </td>

      <!-- Views cell -->
      <td class="p-4 text-sm text-[#C2C2C2] text-center align-top">
        <?php echo e($profile->views_count); ?>

      </td>

      <!-- Clicks cell -->
      <td class="p-4 text-sm text-[#C2C2C2] text-center align-top">
        <?php echo e($profile->clicks_count); ?>

      </td>

      <!-- Actions cell -->
      <td class="p-4 align-top">
        <div class="flex items-center justify-end space-x-3">
          <?php if($profile->is_vip): ?>
          <span class="px-2 py-1 text-sm text-gray-400">
            Премиум
          </span>
          <?php else: ?>          
          <span class="px-2 py-1 bg-[#6340FF] hover:bg-[#5737e7] text-white rounded text-xs">
            Рекламировать
          </span>
          <?php endif; ?>
        <form action="<?php echo e(route('user.profiles.destroy', $profile->id)); ?>" method="POST" class="inline"
        x-data="{}"
        @submit.prevent="if (confirm('Вы уверены, что хотите удалить этот профиль?')) $el.submit();">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="text-red-500 hover:text-red-900">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24"
          stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
          d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
        </svg>
        </button>
        </form>

        <a href="<?php echo e(route('user.profiles.edit', $profile->id)); ?>" class="text-[#C2C2C2] hover:text-white">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24"
        stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
          d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
        </svg>
        </a>
        </div>
      </td>
      </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
      </table>

      <!-- Archive link -->
      <div class="mt-5">
      <a href="#" class="text-[#C2C2C2] hover:text-white text-sm underline">Архив анкет (8)</a>
      </div>
    </div>
    </div>


    <!-- Profiles list - Mobile -->
    <div class="lg:hidden space-y-4 md:space-y-0 md:grid md:grid-cols-2 md:gap-4">

    <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="bg-[#191919] rounded-2xl overflow-hidden">
      <div class="p-5">
      <div class="flex items-start justify-between">
      <div class="flex items-center">
      <div class="w-16 h-16 rounded-full overflow-hidden mr-3 bg-gray-800">
        <img src="<?php echo e(asset('storage/' . $profile->primaryImage->path)); ?>" alt="Profile"
        class="w-full h-full object-cover">
      </div>
      <div>
        <div class="flex items-center gap-2">
        <span class="font-medium text-lg"><?php echo e($profile->name); ?>, <?php echo e($profile->age); ?></span>
        <?php if($profile->is_active): ?>
      <span class="text-xs bg-[#5FD013] text-black px-2 py-0.5 rounded-md">Активна</span>
    <?php else: ?>
    <span class="text-xs bg-[#49494999] text-white px-2 py-0.5 rounded-md">Неактивна</span>
  <?php endif; ?>
        </div>
        <div class="text-xs text-gray-400">Анкета добавлена <?php echo e($profile->created_at->format('d.m.Y')); ?></div>
      </div>
      </div>
      </div>

      <div class="mt-4 space-y-2 text-sm">
      <div class="flex items-center text-[#C2C2C2]">
      <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 mr-1 flex-shrink-0" viewBox="0 0 24 24">
        <circle cx="12" cy="12" r="10" fill="none" stroke="#FF000099" stroke-width="2" />
        <text x="12" y="16" text-anchor="middle" font-size="12" font-weight="bold" fill="#FF000099"
        font-family="Arial, sans-serif">M</text>
      </svg>
      <?php $__currentLoopData = $profile->neighborhoods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $neighborhood): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <span>
      <?php echo e($neighborhood->name); ?><?php echo e($key < count($profile->neighborhoods) - 1 ? ',' : '' ); ?>

     </span>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="flex items-center text-[#C2C2C2]">
      <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 mr-1 flex-shrink-0" viewBox="0 0 24 24">
        <circle cx="12" cy="12" r="10" fill="none" stroke="#FF000099" stroke-width="2" />
        <text x="12" y="16" text-anchor="middle" font-size="12" font-weight="bold" fill="#FF000099"
        font-family="Arial, sans-serif">M</text>
      </svg>
      <?php $__currentLoopData = $profile->metroStations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $metroStation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      м. <?php echo e($metroStation->name); ?>

      <?php if($key < count($profile->metroStations) - 1): ?>
      ,
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      </div>

      <!-- Stats -->
      <div class="text-center mt-5 pb-5 border-b border-gray-800">
      <div class="flex justify-between mb-2">
      <div class="text-white">Просмотры</div>
      <div class="text-sm text-gray-400"><?php echo e($profile->views_count); ?></div>
      </div>
      <div class="flex justify-between mb-2">
      <div class="text-white">Клики</div>
      <div class="text-sm text-gray-400"><?php echo e($profile->clicks_count); ?></div>
      </div>
      <div class="flex justify-between mb-2">
      <div class="text-white">Реклама</div>
      <?php if($profile->is_vip): ?>
          <div class="text-sm text-gray-400">
            Премиум
          </div>
          <?php else: ?>          
          <div class="px-2 py-1 bg-[#6340FF] hover:bg-[#5737e7] text-white rounded text-xs">
            Рекламировать
          </div>
          <?php endif; ?>
      </div>
      </div>


      <!-- Actions -->
      <div class="">
      <form action="<?php echo e(route('user.profiles.destroy', $profile->id)); ?>" method="POST" class="w-full" x-data="{}"
      @submit.prevent="if (confirm('Вы уверены, что хотите удалить этот профиль?')) $el.submit();">
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
      <button type="submit" class="w-full py-3 text-red-900 mb-2">
        Удалить анкету
      </button>
      </form>
      <a href="<?php echo e(route('user.profiles.edit', $profile->id)); ?>"
      class="block w-full py-3 bg-[#6340FF] hover:bg-[#5737e7] rounded-xl text-white transition text-center">
      Редактировать
      </a>
      </div>
      </div>
    </div>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

    <!-- Archive link - Mobile -->
    <div class="mt-4 lg:hidden">
    <a href="#" class="text-[#C2C2C2] hover:text-white text-sm">Архив анкет (8)</a>
    </div>
  <?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\akess\OneDrive\Documents\jobs\renting\resources\views/profiles/index.blade.php ENDPATH**/ ?>