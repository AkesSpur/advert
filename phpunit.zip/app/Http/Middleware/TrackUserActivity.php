<?php

namespace App\Http\Middleware;

use App\Models\Profile;
use App\Models\User;
use Carbon\Carbon;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TrackUserActivity
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        // Get the response
        $response = $next($request);
        
        // Check if user is authenticated
        if (Auth::check()) {
            $user = User::findOrFail(Auth::id());
            
            // Update the last_active timestamp on the user instead of the profile
            $user->update(['last_active' => now()]);
        }
        
        return $response;
    }
}