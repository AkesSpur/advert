<?php

namespace App\Http\Controllers;

use App\Models\CustomCategory;
use App\Models\FooterMenu;
use App\Models\Neighborhood;
use App\Models\Service;
use App\Models\MetroStation;
use App\Models\Profile;
use App\Models\TopMenu;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;

class PageController extends Controller
{
    public function index(Request $request, $slug = null)
    {
        // Get filter parameters
        $filter = $request->input('filter', 'all');
        $sort = $request->input('sort');
        $service = null;
        $metro = null;
        $price = null;
        $age = null;
        $hairColor = null;
        $height = null;
        $weight = null;
        $size = null;
        $neighborhood = null;
        $district = $request->input('district');
        
        // Check if we're using directory-style URLs
        $routeName = $request->route()->getName();
        if ($routeName && $slug) {
            // Use the appropriate filter based on route name
            switch ($routeName) {
                case 'home.service':
                    $service = $slug; // Use slug directly instead of deslugifying
                    break;
                case 'home.metro':
                    $metro = $slug; // Use slug directly instead of deslugifying
                    break;
                case 'home.price':
                    $price = $slug; // Still deslugify for price
                    break;
                case 'home.age':
                    $age = $slug; // Still deslugify for age
                    break;
                case 'home.hair_color':
                    switch ($slug) {
                        case 'blondes':
                            $slug = 'Блондинка';
                            break;
                            case 'brunettes':
                                $slug = 'Брюнетка';
                                break;
                            case 'brown-haired':
                                $slug = 'Шатенка';
                                break;
                            case 'Wolverines':
                                $slug = 'Русая';
                                break;
                            default:
                                $slug = 'Рыжая';
                                break;
                    }
                    $hairColor = $slug;
                    break;
                case 'home.height':
                    $height = $slug;
                    break;
                case 'home.weight':
                    $weight = $slug;
                    break;
                case 'home.breast-size':
                    $size = $slug;
                    break;
                case 'home.neighborhood':
                    $neighborhood = $slug;
                    break;
            }
        } else {
            // For backward compatibility, still check query parameters
            $service = $request->input('service');
            $metro = $request->input('metro');
            $price = $request->input('price');
            $age = $request->input('age');
            $hairColor = $request->input('hair_color');
            $height = $request->input('height');
            $weight = $request->input('weight');
            $size = $request->input('size');
            $neighborhood = $request->input('neighborhood');
        }

        // First, get all VIP profiles regardless of filters
        $vipQuery = Profile::with(['metroStations', 'services', 'images', 'video', 'activeAds.adTariff'])
            ->where('profiles.is_active', true)
            ->where('is_vip', true);

        // Now create the filtered query for non-VIP profiles
        $filteredQuery = Profile::with(['metroStations', 'services', 'images', 'video', 'activeAds.adTariff'])
            ->where('profiles.is_active', true);

        // Apply all filters to the filtered query
        if ($service) {
            $filteredQuery->whereHas('services', function ($query) use ($service) {
                $query->where('slug', $service);
            });
        }

        if ($metro) {
            $filteredQuery->whereHas('metroStations', function ($query) use ($metro) {
                $query->where('slug', $metro);
            });
        }

        if ($hairColor) {
            $filteredQuery->where('hair_color', $hairColor);
        }

        if ($height) {
            switch ($height) {
                case 'height-under-150':
                    $filteredQuery->where('height', '<=', 150);
                    break;
                case 'height-under-165':
                    $filteredQuery->where('height', '<=', 165);
                    break;
                case 'height-165-180':
                    $filteredQuery->whereBetween('height', [165, 180]);
                    break;
                case 'height-over-180':
                    $filteredQuery->where('height', '>', 180);
                    break;
            }
        }

        if ($weight) {
            switch ($weight) {
                case 'weight-under-45':
                    $filteredQuery->where('weight', '<=', 45);
                    break;
                case 'weight-under-50':
                    $filteredQuery->where('weight', '<=', 50);
                    break;
                case 'weight-50-65':
                    $filteredQuery->whereBetween('weight', [50, 65]);
                    break;
                case 'weight-over-65':
                    $filteredQuery->where('weight', '>', 65);
                    break;
            }
        }

        if ($size) {
            switch ($size) {
                case 'size-under-1':
                    $filteredQuery->where('size', '<', 1);
                    break;
                case 'size-1-2':
                    $filteredQuery->whereBetween('size', [1, 2]);
                    break;
                case 'size-2-3':
                    $filteredQuery->whereBetween('size', [2, 3]);
                    break;
                case 'size-over-3':
                    $filteredQuery->where('size', '>', 3);
                    break;
            }
        }

        if ($neighborhood) {
            $filteredQuery->whereHas('neighborhoods', function ($query) use ($neighborhood) {
                $query->where('slug', $neighborhood);
            });
        }

        if ($district) {
            $filteredQuery->whereHas('neighborhoods', function ($query) use ($district) {
                $query->where('name', $district);
            });
        }

        if ($price) {
            switch ($price) {
                case 'price-under-2000':
                    $filteredQuery->where('profiles.vyezd_1hour', '<=', 2000);
                    break;
                case 'price-1500':
                    $filteredQuery->where('profiles.vyezd_1hour', '=', 1500);
                    break;
                case 'price-under-2500':
                    $filteredQuery->where('profiles.vyezd_1hour', '<=', 2500);
                    break;
                case 'price-under-5000':
                    $filteredQuery->where('profiles.vyezd_1hour', '<=', 5000);
                    break;
                case 'price-under-8000':
                    $filteredQuery->where('profiles.vyezd_1hour', '<=', 8000);
                    break;
                case 'price-over-5000':
                    $filteredQuery->where('profiles.vyezd_1hour', '>', 5000);
                    break;
                case 'price-over-8000':
                    $filteredQuery->where('profiles.vyezd_1hour', '>', 8000);
                    break;
                case 'price-over-10000':
                    $filteredQuery->where('profiles.vyezd_1hour', '>', 10000);
                    break;
            }
        }

        // Handle age filter
        if ($age) {
            switch ($age) {
                case 'age-under-22':
                    $filteredQuery->where('profiles.age', '<=', 22);
                    break;
                case 'age-18':
                    $filteredQuery->where('profiles.age', '=', 18);
                    break;
                case 'age-under-20':
                    $filteredQuery->where('profiles.age', '<=', 20);
                    break;
                case 'age-under-25':
                    $filteredQuery->where('profiles.age', '<=', 25);
                    break;
                case 'age-under-30':
                    $filteredQuery->where('profiles.age', '<=', 30);
                    break;
                case 'age-30-35':
                    $filteredQuery->whereBetween('profiles.age', [30, 35]);
                    break;
                case 'age-35-40':
                    $filteredQuery->whereBetween('profiles.age', [35, 40]);
                    break;
                case 'age-28-40':
                    $filteredQuery->whereBetween('profiles.age', [28, 40]);
                    break;
                case 'age-over-40':
                    $filteredQuery->where('profiles.age', '>', 40);
                    break;
            }
        }

        // Handle price filter
        $price = request('price');
        if ($price) {
            preg_match_all('/\d+/', $price, $matches);
            if (count($matches[0]) === 2) {
                $minPrice = (int)$matches[0][0];
                $maxPrice = (int)$matches[0][1];
                $filteredQuery->where(function($query) use ($minPrice, $maxPrice) {
                    $query->whereBetween('appartamenti_1hour', [$minPrice, $maxPrice])
                          ->orWhereBetween('vyezd_1hour', [$minPrice, $maxPrice]);
                });
            }
        }

        // Handle height filter
        $height = request('height');
        if ($height) {
            preg_match_all('/\d+/', $height, $matches);
            if (count($matches[0]) === 2) {
                $minHeight = (int)$matches[0][0];
                $maxHeight = (int)$matches[0][1];
                $filteredQuery->whereBetween('height', [$minHeight, $maxHeight]);
            }
        }

        // Handle weight filter
        $weight = request('weight');
        if ($weight) {
            preg_match_all('/\d+/', $weight, $matches);
            if (count($matches[0]) === 2) {
                $minWeight = (int)$matches[0][0];
                $maxWeight = (int)$matches[0][1];
                $filteredQuery->whereBetween('weight', [$minWeight, $maxWeight]);
            }
        }

        // Handle size (breast size) filter
        $size = request('size');
        if ($size) {
            $filteredQuery->where('size', $size);
        }

        // Handle hair color filter
        $hairColor = request('hair-color');
        if ($hairColor) {
            $filteredQuery->where('hair_color', $hairColor);
        }

        // Apply additional filters based on filter parameter (except for VIP filter)
        if ($filter !== 'vip') {
            switch ($filter) {
                case 'video':
                    $filteredQuery->hasVideo();
                    break;
                case 'new':
                    $filteredQuery->isNew();
                    break;
                case 'cheap':
                    $filteredQuery->isCheap();
                    break;
                case 'verified':
                    $filteredQuery->isVerified();
                    break;
            }

            // For non-VIP filter, exclude VIP profiles from filtered query to avoid duplicates
            $filteredQuery->where('is_vip', false);
        }

        // For VIP filter, we'll only use the VIP query
        if ($filter === 'vip' && !$sort) {
            // Just use the VIP query directly
            $profiles = $vipQuery
                ->with(['metroStations', 'services', 'images', 'video', 'activeAds.adTariff'])
                ->withCount(['activeAds as vip_score' => function ($query) {
                    $query->whereHas('adTariff', fn($q) => $q->where('slug', 'vip'))
                        ->where('is_paused', 0);
                }])
                ->withCount(['activeAds as priority_score' => function ($query) {
                    $query->whereHas('adTariff', fn($q) => $q->where('slug', 'priority'))
                        ->where('is_paused', 0)
                        ->select(DB::raw('MAX(priority_level)'));
                }])
                ->orderByDesc('vip_score')
                ->orderByDesc('priority_score')
                ->paginate(12);
        } else {
            // When sorting is applied, ignore VIP and priority conditions
            if ($sort) {
                // Combine VIP and non-VIP profiles for sorting
                $combinedQuery = Profile::with(['metroStations', 'services', 'images', 'video', 'activeAds.adTariff'])
                    ->where('profiles.is_active', true);
                
                // Apply all the same filters to the combined query
                if ($service) {
                    $combinedQuery->whereHas('services', function ($query) use ($service) {
                        $query->where('slug', $service);
                    });
                }
                
                if ($metro) {
                    $combinedQuery->whereHas('metroStations', function ($query) use ($metro) {
                        $query->where('slug', $metro);
                    });
                }
                
                if ($district) {
                    $combinedQuery->whereHas('neighborhoods', function ($query) use ($district) {
                        $query->where('name', $district);
                    });
                }
                
                if ($price) {
                    preg_match_all('/\d+/', $price, $matches);
                    if (count($matches[0]) === 2) {
                        $minPrice = (int)$matches[0][0];
                        $maxPrice = (int)$matches[0][1];
                        $combinedQuery->whereBetween('profiles.vyezd_1hour', [$minPrice, $maxPrice]);
                    }
                }
                
                if ($age) {
                    preg_match_all('/\d+/', $age, $matches);
                    if (count($matches[0]) === 2) {
                        $minAge = (int)$matches[0][0];
                        $maxAge = (int)$matches[0][1];
                        $combinedQuery->whereBetween('profiles.age', [$minAge, $maxAge]);
                    }
                }
                
                // Apply additional filters based on filter parameter
                if ($filter !== 'all' && $filter !== 'vip') {
                    switch ($filter) {
                        case 'video':
                            $combinedQuery->hasVideo();
                            break;
                        case 'new':
                            $combinedQuery->isNew();
                            break;
                        case 'cheap':
                            $combinedQuery->isCheap();
                            break;
                        case 'verified':
                            $combinedQuery->isVerified();
                            break;
                    }
                }
                
                // Apply sorting to all profiles
                switch ($sort) {
                    case 'popular':
                        $combinedQuery->orderByDesc('profiles.views_count');
                        break;
                    case 'cheapest':
                        $combinedQuery->orderBy('profiles.vyezd_1hour');
                        break;
                    case 'expensive':
                        $combinedQuery->orderByDesc('profiles.vyezd_1hour');
                        break;
                    default:
                        $combinedQuery->orderByDesc('profiles.views_count');
                }
                
                // Paginate the combined results
                $profiles = $combinedQuery->paginate(12);
            } else {
                // For all other filters without sorting, we'll handle VIP and non-VIP profiles separately
                // Apply sorting only to non-VIP profiles
                $filteredQuery->with(['metroStations', 'services', 'images', 'video', 'activeAds.adTariff'])
                    ->withCount(['activeAds as priority_score' => function ($query) {
                        $query->whereHas('adTariff', fn($q) => $q->where('slug', 'priority'))
                            ->where('is_paused', 0)
                            ->select(DB::raw('MAX(priority_level)'));
                    }])
                    ->orderByDesc('priority_score')
                    ->orderByDesc('profiles.views_count');

                // Get VIP profiles first (with their own sorting by vip_score and priority_score)
                $vipProfiles = $vipQuery
                    ->with(['metroStations', 'services', 'images', 'video', 'activeAds.adTariff'])
                    ->withCount(['activeAds as vip_score' => function ($query) {
                        $query->whereHas('adTariff', fn($q) => $q->where('slug', 'vip'))
                            ->where('is_paused', 0);
                    }])
                    ->withCount(['activeAds as priority_score' => function ($query) {
                        $query->whereHas('adTariff', fn($q) => $q->where('slug', 'priority'))
                            ->where('is_paused', 0)
                            ->select(DB::raw('MAX(priority_level)'));
                    }])
                    ->orderByDesc('vip_score')
                    ->orderByDesc('priority_score')
                    ->get();

                // Get non-VIP profiles with applied sorting
                $filteredProfiles = $filteredQuery->get();

                // Merge collections with VIP profiles first, then paginate
                $allProfiles = $vipProfiles->concat($filteredProfiles);
                $profiles = new LengthAwarePaginator(
                    $allProfiles->forPage(request()->input('page', 1), 2),
                    $allProfiles->count(),
                    2,
                    request()->input('page', 1),
                    ['path' => request()->url(), 'query' => request()->query()]
                );
            }
        }

        // Increment view count for displayed profiles
        if (!$request->ajax()) {
            foreach ($profiles as $profile) {
                if (method_exists($profile, 'incrementViewCount')) {
                    $profile->incrementViewCount();
                } else {
                    $profile->increment('views_count');
                }
            }
        }

        if ($request->ajax()) {
            if ($profiles->isEmpty() && $request->input('page', 1) > 1) {
                return response()->json(['html' => '', 'has_more_pages' => false]);
            }
            return response()->json([
                'html' => view('partials.profiles-list', compact('profiles'))->render(),
                'has_more_pages' => $profiles->hasMorePages()
            ]);
        }

        // Sidebar: Services
        $services = Service::withCount(['profiles as profiles_count' => function ($query) {
            $query->where('is_active', true);
        }])
            ->orderBy('name')
            ->get()
            ->map(function($s) {
                // Generate slug if it doesn't exist in the database
                $slug = isset($s->slug) ? $s->slug : slugify($s->name);
                return [
                    'name' => $s->name, 
                    'slug' => $slug,
                    'count' => $s->profiles_count
                ];
            });

        //neighborhoods
        $neighborhoods = Neighborhood::withCount(['profiles as profiles_count' => function ($query) {
            $query->where('is_active', true);
        }])
            ->orderBy('name')
            ->get()
            ->map(function($s) {
                // Generate slug if it doesn't exist in the database
                $slug = isset($s->slug) ? $s->slug : slugify($s->name);
                return [
                    'name' => $s->name, 
                    'slug' => $slug,
                    'count' => $s->profiles_count
                ];
            }); 

        // Sidebar: Metro stations grouped by alphabet
        $metroStations = MetroStation::withCount(['profiles as profiles_count' => function ($query) {
            $query->where('is_active', true);
        }])
            ->orderBy('name')
            ->get()
            ->groupBy(fn($item) => mb_strtoupper(mb_substr($item->name, 0, 1, 'UTF-8')))
            ->map(fn($group) => $group->map(fn($station) => [
                'name' => $station->name,
                'slug' => $station->slug,
                'count' => $station->profiles_count
            ]))
            ->toArray();

        // Get active custom categories for filtering
        $customCategories = CustomCategory::where('status', 1)->orderBy('name')->get();

        $topMenus = TopMenu::all();
        $footerMenus = FooterMenu::all();

        return view('home.index', compact('services',
         'metroStations',
         'neighborhoods',
         'profiles',
         'filter',
         'topMenus',
         'footerMenus', 
        'sort',
         'customCategories'
        ));
    }


    public function profileClick($id)
    {
        $profile = Profile::findOrFail($id);
        $profile->incrementClickCount();

        return redirect()->route('profiles.view', $profile->id);
    }
    
    /**
     * Filter profiles by custom category
     */
    public function filterByCustomCategory($slug)
    {
        // Find the custom category by slug
        $customCategory = CustomCategory::where('slug', $slug)->where('status', 1)->firstOrFail();
        
        // Use the getMatchingProfiles method from the CustomCategory model
        // This handles all filters: age, weight, height, hair color, size, price, services, metro stations, and neighborhoods
        $matchingProfiles = $customCategory->getMatchingProfiles();

        // Convert the collection to a paginator
        $page = request()->get('page', 1);
        $perPage = 20;
        $offset = ($page - 1) * $perPage;
        
        $profiles = new \Illuminate\Pagination\LengthAwarePaginator(
            $matchingProfiles->slice($offset, $perPage),
            $matchingProfiles->count(),
            $perPage,
            $page,
            ['path' => request()->url(), 'query' => request()->query()]
        );

        
        // Sidebar: Services
        $services = Service::withCount(['profiles as profiles_count' => function ($query) {
            $query->where('is_active', true);
        }])
            ->orderBy('name')
            ->get()
            ->map(function($s) {
                // Generate slug if it doesn't exist in the database
                $slug = isset($s->slug) ? $s->slug : slugify($s->name);
                return [
                    'name' => $s->name, 
                    'slug' => $slug,
                    'count' => $s->profiles_count
                ];
            });

        //neighborhoods
        $neighborhoods = Neighborhood::withCount(['profiles as profiles_count' => function ($query) {
            $query->where('is_active', true);
        }])
            ->orderBy('name')
            ->get()
            ->map(function($s) {
                // Generate slug if it doesn't exist in the database
                $slug = isset($s->slug) ? $s->slug : slugify($s->name);
                return [
                    'name' => $s->name, 
                    'slug' => $slug,
                    'count' => $s->profiles_count
                ];
            }); 

        // Sidebar: Metro stations grouped by alphabet
        $metroStations = MetroStation::withCount(['profiles as profiles_count' => function ($query) {
            $query->where('is_active', true);
        }])
            ->orderBy('name')
            ->get()
            ->groupBy(fn($item) => mb_strtoupper(mb_substr($item->name, 0, 1, 'UTF-8')))
            ->map(fn($group) => $group->map(fn($station) => [
                'name' => $station->name,
                'slug' => $station->slug,
                'count' => $station->profiles_count
            ]))
            ->toArray();

        // Get active custom categories for filtering
        $customCategories = CustomCategory::where('status', 1)->orderBy('name')->get();
        
        // Set filter information for the view
        $filter = [
            'type' => 'custom_category',
            'value' => $customCategory->name,
            'title' => $customCategory->h1 ?: $customCategory->name,
            'description' => $customCategory->description
        ];
        
        $sort = request('sort', 'default');

        $topMenus = TopMenu::all();
        $footerMenus = FooterMenu::all();
        
        return view('home.index', compact('services',
         'metroStations', 
         'neighborhoods',
          'profiles',
          'filter',
          'sort',
          'topMenus',
          'footerMenus',
          'customCategories'
        ));
    }

    public function show($id)
    {
        $profile = Profile::with(['metroStations', 'services', 'images', 'video'])->findOrFail($id);
        $profile->incrementViewCount();

        return view('profiles.profile', compact('profile'));
    }
    
    /**
     * Apply age filters to the query
     * 
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @param array $filters
     * @return \Illuminate\Database\Eloquent\Builder
     */
    protected function applyAgeFilters($query, $filters)
    {
        if (empty($filters)) {
            return $query;
        }
        
        $conditions = [];
        
        foreach ($filters as $filter) {
            switch ($filter) {
                case 'age-18-25':
                    $conditions[] = ['age', '>=', 18];
                    $conditions[] = ['age', '<=', 25];
                    break;
                case 'age-25-30':
                    $conditions[] = ['age', '>=', 25];
                    $conditions[] = ['age', '<=', 30];
                    break;
                case 'age-30-35':
                    $conditions[] = ['age', '>=', 30];
                    $conditions[] = ['age', '<=', 35];
                    break;
                case 'age-35-40':
                    $conditions[] = ['age', '>=', 35];
                    $conditions[] = ['age', '<=', 40];
                    break;
                case 'age-over-40':
                    $conditions[] = ['age', '>', 40];
                    break;
            }
        }
        
        // Apply the conditions using OR between different age ranges
        return $query->where(function($q) use ($conditions) {
            foreach ($conditions as $index => $condition) {
                if ($index === 0) {
                    $q->where($condition[0], $condition[1], $condition[2]);
                } else {
                    // If this is a continuation of a range (e.g., age >= 18 AND age <= 25)
                    if ($index % 2 === 1 && $index > 0 && isset($conditions[$index-1]) && $conditions[$index-1][0] === $condition[0]) {
                        $q->where($condition[0], $condition[1], $condition[2]);
                    } else {
                        $q->orWhere($condition[0], $condition[1], $condition[2]);
                    }
                }
            }
        });
    }
    
    /**
     * Apply weight filters to the query
     * 
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @param array $filters
     * @return \Illuminate\Database\Eloquent\Builder
     */
    protected function applyWeightFilters($query, $filters)
    {
        if (empty($filters)) {
            return $query;
        }
        
        $conditions = [];
        
        foreach ($filters as $filter) {
            switch ($filter) {
                case 'weight-under-50':
                    $conditions[] = ['weight', '<', 50];
                    break;
                case 'weight-50-60':
                    $conditions[] = ['weight', '>=', 50];
                    $conditions[] = ['weight', '<=', 60];
                    break;
                case 'weight-60-70':
                    $conditions[] = ['weight', '>=', 60];
                    $conditions[] = ['weight', '<=', 70];
                    break;
                case 'weight-over-70':
                    $conditions[] = ['weight', '>', 70];
                    break;
            }
        }
        
        // Apply the conditions using OR between different weight ranges
        return $query->where(function($q) use ($conditions) {
            foreach ($conditions as $index => $condition) {
                if ($index === 0) {
                    $q->where($condition[0], $condition[1], $condition[2]);
                } else {
                    // If this is a continuation of a range (e.g., weight >= 50 AND weight <= 60)
                    if ($index % 2 === 1 && $index > 0 && isset($conditions[$index-1]) && $conditions[$index-1][0] === $condition[0]) {
                        $q->where($condition[0], $condition[1], $condition[2]);
                    } else {
                        $q->orWhere($condition[0], $condition[1], $condition[2]);
                    }
                }
            }
        });
    }
    
    /**
     * Apply size (height) filters to the query
     * 
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @param array $filters
     * @return \Illuminate\Database\Eloquent\Builder
     */
    protected function applySizeFilters($query, $filters)
    {
        if (empty($filters)) {
            return $query;
        }
        
        $conditions = [];
        
        foreach ($filters as $filter) {
            switch ($filter) {
                case 'height-under-160':
                    $conditions[] = ['height', '<', 160];
                    break;
                case 'height-160-170':
                    $conditions[] = ['height', '>=', 160];
                    $conditions[] = ['height', '<=', 170];
                    break;
                case 'height-170-180':
                    $conditions[] = ['height', '>=', 170];
                    $conditions[] = ['height', '<=', 180];
                    break;
                case 'height-over-180':
                    $conditions[] = ['height', '>', 180];
                    break;
            }
        }
        
        // Apply the conditions using OR between different height ranges
        return $query->where(function($q) use ($conditions) {
            foreach ($conditions as $index => $condition) {
                if ($index === 0) {
                    $q->where($condition[0], $condition[1], $condition[2]);
                } else {
                    // If this is a continuation of a range (e.g., height >= 160 AND height <= 170)
                    if ($index % 2 === 1 && $index > 0 && isset($conditions[$index-1]) && $conditions[$index-1][0] === $condition[0]) {
                        $q->where($condition[0], $condition[1], $condition[2]);
                    } else {
                        $q->orWhere($condition[0], $condition[1], $condition[2]);
                    }
                }
            }
        });
    }
    
    /**
     * Apply hair color filters to the query
     * 
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @param array $filters
     * @return \Illuminate\Database\Eloquent\Builder
     */
    protected function applyHairColorFilters($query, $filters)
    {
        if (empty($filters)) {
            return $query;
        }
        
        return $query->where(function($q) use ($filters) {
            foreach ($filters as $index => $hairColor) {
                if ($index === 0) {
                    $q->where('hair_color', $hairColor);
                } else {
                    $q->orWhere('hair_color', $hairColor);
                }
            }
        });
    }
}


// public function index(Request $request)
//     {
//         // Get filter parameters
//         $filter = $request->input('filter', 'all');
//         $sort = $request->input('sort');
//         $service = $request->input('service');
//         $metro = $request->input('metro');
//         $price = $request->input('price');
//         $age = $request->input('age');
//         $district = $request->input('district');

//         // First, get all VIP profiles regardless of filters
//         $vipQuery = Profile::with(['metroStations', 'services', 'images', 'video', 'activeAds.adTariff'])
//             ->where('profiles.is_active', true)
//             ->where('is_vip', true);

//         // Now create the filtered query for non-VIP profiles
//         $filteredQuery = Profile::with(['metroStations', 'services', 'images', 'video', 'activeAds.adTariff'])
//             ->where('profiles.is_active', true);

//         // Apply all filters to the filtered query
//         if ($service) {
//             $filteredQuery->whereHas('services', function ($query) use ($service) {
//                 $query->where('name', $service);
//             });
//         }

//         if ($metro) {
//             $filteredQuery->whereHas('metroStations', function ($query) use ($metro) {
//                 $query->where('name', $metro);
//             });
//         }

//         if ($district) {
//             $filteredQuery->whereHas('neighborhoods', function ($query) use ($district) {
//                 $query->where('name', $district);
//             });
//         }

//         if ($price) {
//             // Parse price range like "От 2000 до 3000 руб"
//             preg_match_all('/\d+/', $price, $matches);
//             if (count($matches[0]) === 2) {
//                 $minPrice = (int)$matches[0][0];
//                 $maxPrice = (int)$matches[0][1];
//                 $filteredQuery->whereBetween('profiles.vyezd_1hour', [$minPrice, $maxPrice]);
//             }
//         }

//         if ($age) {
//             preg_match_all('/\d+/', $age, $matches);
//             if (count($matches[0]) === 2) {
//                 $minAge = (int)$matches[0][0];
//                 $maxAge = (int)$matches[0][1];
//                 $filteredQuery->whereBetween('profiles.age', [$minAge, $maxAge]);
//             }
//         }

//         // Apply additional filters based on filter parameter (except for VIP filter)
//         if ($filter !== 'vip') {
//             switch ($filter) {
//                 case 'video':
//                     $filteredQuery->hasVideo();
//                     break;
//                 case 'new':
//                     $filteredQuery->isNew();
//                     break;
//                 case 'cheap':
//                     $filteredQuery->isCheap();
//                     break;
//                 case 'verified':
//                     $filteredQuery->isVerified();
//                     break;
//             }

//             // For non-VIP filter, exclude VIP profiles from filtered query to avoid duplicates
//             $filteredQuery->where('is_vip', false);
//         }

//         // For VIP filter, we'll only use the VIP query
//         if ($filter === 'vip') {
//             // Just use the VIP query directly
//             $profiles = $vipQuery
//                 ->with(['metroStations', 'services', 'images', 'video', 'activeAds.adTariff'])
//                 ->withCount(['activeAds as vip_score' => function ($query) {
//                     $query->whereHas('adTariff', fn($q) => $q->where('slug', 'vip'))
//                         ->where('is_paused', 0);
//                 }])
//                 ->withCount(['activeAds as priority_score' => function ($query) {
//                     $query->whereHas('adTariff', fn($q) => $q->where('slug', 'priority'))
//                         ->where('is_paused', 0)
//                         ->select(DB::raw('MAX(priority_level)'));
//                 }])
//                 ->orderByDesc('vip_score')
//                 ->orderByDesc('priority_score')
//                 ->paginate(12);
//         } else {
//             // For all other filters, we'll handle VIP and non-VIP profiles separately
//             // Apply sorting only to non-VIP profiles
//             $filteredQuery->with(['metroStations', 'services', 'images', 'video', 'activeAds.adTariff'])
//                 ->withCount(['activeAds as priority_score' => function ($query) {
//                     $query->whereHas('adTariff', fn($q) => $q->where('slug', 'priority'))
//                         ->where('is_paused', 0)
//                         ->select(DB::raw('MAX(priority_level)'));
//                 }])
//                 ->orderByDesc('priority_score');

//             // Apply sorting only to non-VIP profiles
//             switch ($sort) {
//                 case 'popular':
//                     $filteredQuery->orderByDesc('profiles.views_count');
//                     break;
//                 case 'cheapest':
//                     $filteredQuery->orderBy('profiles.vyezd_1hour');
//                     break;
//                 case 'expensive':
//                     $filteredQuery->orderByDesc('profiles.vyezd_1hour');
//                     break;
//                 default:
//                     $filteredQuery->orderByDesc('profiles.views_count');
//             }

//             // Get VIP profiles first (with their own sorting by vip_score and priority_score)
//             $vipProfiles = $vipQuery
//                 ->with(['metroStations', 'services', 'images', 'video', 'activeAds.adTariff'])
//                 ->withCount(['activeAds as vip_score' => function ($query) {
//                     $query->whereHas('adTariff', fn($q) => $q->where('slug', 'vip'))
//                         ->where('is_paused', 0);
//                 }])
//                 ->withCount(['activeAds as priority_score' => function ($query) {
//                     $query->whereHas('adTariff', fn($q) => $q->where('slug', 'priority'))
//                         ->where('is_paused', 0)
//                         ->select(DB::raw('MAX(priority_level)'));
//                 }])
//                 ->orderByDesc('vip_score')
//                 ->orderByDesc('priority_score')
//                 ->get();

//             // Get non-VIP profiles with applied sorting
//             $filteredProfiles = $filteredQuery->get();

//             // Merge collections with VIP profiles first, then paginate
//             $allProfiles = $vipProfiles->concat($filteredProfiles);
//             $profiles = new LengthAwarePaginator(
//                 $allProfiles->forPage(request()->input('page', 1), 12),
//                 $allProfiles->count(),
//                 12,
//                 request()->input('page', 1),
//                 ['path' => request()->url(), 'query' => request()->query()]
//             );
//         }

//         // Increment view count for displayed profiles
//         foreach ($profiles as $profile) {
//             if (method_exists($profile, 'incrementViewCount')) {
//                 $profile->incrementViewCount();
//             } else {
//                 $profile->increment('views_count');
//             }
//         }

//         // Sidebar: Services
//         $services = Service::withCount(['profiles as profiles_count' => function ($query) {
//             $query->where('is_active', true);
//         }])
//             ->orderBy('name')
//             ->get()
//             ->map(fn($s) => ['name' => $s->name, 'count' => $s->profiles_count]);

//         // Sidebar: Metro stations grouped by alphabet
//         $metroStations = MetroStation::withCount(['profiles as profiles_count' => function ($query) {
//             $query->where('is_active', true);
//         }])
//             ->orderBy('name')
//             ->get()
//             ->groupBy(fn($item) => mb_strtoupper(mb_substr($item->name, 0, 1, 'UTF-8')))
//             ->map(fn($group) => $group->map(fn($station) => [
//                 'name' => $station->name,
//                 'count' => $station->profiles_count
//             ]))
//             ->toArray();


//         return view('home.index', compact('services', 'metroStations', 'profiles', 'filter', 'sort'));
//     }